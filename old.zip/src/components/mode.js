import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Icon } from '@components/icons';
// import { email } from '@config';
// import { Side } from '@components';

const Button = styled.button`
  margin-top: auto;
  cursor: pointer;
  /* background-color: ${props => (props.mode === 'dark' ? '#fff' : '#00051de8')}; */
  border-radius: 50% !important;
  padding: 15px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -ms-flex-direction: column;
  flex-direction: column;
  justify-self: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  outline: none;
  border: none;
`;
const ModeWrapper = styled.div`
  position: fixed;
  bottom: 30px;
  right: 30px;
  width: auto;
  height: auto;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -ms-flex-direction: column;
  flex-direction: column;
  justify-self: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  background-color: transparent;
  z-index: 100000;
`;

const Mode = ({ darkModeHandler, isDark }) => (
  <ModeWrapper>
    <Button onClick={darkModeHandler} mode={isDark}>
      <Icon name={isDark} />
    </Button>
  </ModeWrapper>
);

Mode.propTypes = {
  isDark: PropTypes.string,
  darkModeHandler: PropTypes.func,
};

export default Mode;
