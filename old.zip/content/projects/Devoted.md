---
date: '2018-12-01'
title: 'Devoted Health'
github: ''
external: 'https://www.devoted.com/'
tech:
  - Gatsby
  - TypeScript
  - Algolia
company: 'Upstatement'
showInProjects: false
---

A site for a revolutionary healthcare company, including an Algolia instant search integration
