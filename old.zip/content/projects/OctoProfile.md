---
date: '2019-07-15'
title: 'OctoProfile'
github: 'https://github.com/bchiang7/octoprofile'
external: 'https://octoprofile.now.sh'
tech:
  - Next.js
  - Chart.js
  - GitHub API
showInProjects: false
---

A nicer look at your GitHub profile and repo stats. Includes data visualizations of your top languages, starred repositories, and sort through your top repos by number of stars, forks, and size.
