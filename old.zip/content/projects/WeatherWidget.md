---
date: '2016-11-16'
title: 'Weather Widget'
github: 'https://github.com/bchiang7/DemoWebApp'
external: 'http://quiet-dusk-89245.herokuapp.com/'
tech:
  - Node
  - Express
  - EJS
showInProjects: false
---

Simple weather app made with Node.js, Express, and Heroku. Utilized the OpenWeatherMap API and Google Maps API.
