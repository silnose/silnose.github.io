---
date: '2016-04-01'
title: 'CourseSource'
github: 'https://github.com/bchiang7/WebDevSpring2016/tree/master/public/project'
external: ''
tech:
  - Angular
  - Node
  - Express
  - MongoDB
company: 'Northeastern'
showInProjects: false
---

Web application built on the MEAN (MongoDB, Express, Angular, Node) stack with the intention of providing Northeastern students a better experience browsing the courses offered at Northeastern.
