---
date: '2016-11-01'
title: 'Screentime 2.0'
github: ''
external: 'https://starry.com/blog/product/whats-new-screentime-just-got-better-for-parents'
android: 'https://play.google.com/store/apps/details?id=com.starry.management&hl=en_US'
tech:
  - Cordova
  - Backbone
  - Marionette
company: 'Starry'
showInProjects: true
---

Starry Station android app feature that provided users with the ability to easily filter content, pause the internet, and even create custom rules for blocking apps like Facebook and Twitter right from their phones.
