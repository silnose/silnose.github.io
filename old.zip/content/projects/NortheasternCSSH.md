---
date: '2020-07-16'
title: 'Northeastern CSSH'
github: ''
external: 'https://cssh.northeastern.edu/'
tech:
  - WordPress
  - Timber
  - WordPress Multisite
  - PHP
  - Algolia
  - JS
company: 'Upstatement'
showInProjects: false
---
