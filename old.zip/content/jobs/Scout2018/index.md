---
date: '2018-04-01'
title: 'Studio Developer'
company: 'Scout'
location: 'Northeastern University'
range: 'January - April 2018'
url: 'https://web.northeastern.edu/scout/'
---

- Worked with a team of three designers to build a marketing website and e-commerce platform for [blistabloc](https://blistabloc.com), an ambitious startup originating from Northeastern
- Helped solidify a brand direction for blistabloc that spans both packaging and web
- Interfaced with clients on a weekly basis, providing technological expertise
