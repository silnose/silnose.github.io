---
date: '3'
title: 'OctoProfile'
cover: './octoprofile.png'
github: 'https://github.com/bchiang7/octoprofile'
external: 'https://octoprofile.now.sh'
tech:
  - Next.js
  - Chart.js
  - GitHub API
showInProjects: true
---

A nicer look at your GitHub profile and repository stats with data visualizations of your top languages and stars. Sort through your top repos by number of stars, forks, and size.
